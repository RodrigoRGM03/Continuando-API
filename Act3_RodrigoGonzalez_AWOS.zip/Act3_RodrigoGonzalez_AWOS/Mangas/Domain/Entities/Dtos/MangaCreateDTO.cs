namespace Mangas.Domain.Dtos;


public class MangaCreateDTO
{

    public string Title {get;set;} = null!;

    public string Author {get;set;} = null!;

    




}