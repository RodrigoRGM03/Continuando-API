public class MangaUpdateDTO
{
    public string Title { get; set; }
    public string Author { get; set; }
    public int PublicationYear { get; set; }
    public string Genre { get; set; }
    public int Volumes { get; set; }
    public bool IsCompleted { get; set; }
    
}